﻿using Nemo.Collections.Extensions;
using Nemo.Configuration.Mapping;
using Nemo.Serialization;
using Nemo.Utilities;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Xml;
using System.Xml.Linq;

namespace Nemo.Reflection
{
    public static partial class Reflector
    {
        #region Declarations

        private static readonly MethodInfo _getReflectedTypeMethod = typeof(Reflector).GetMethod("GetReflectedType", BindingFlags.Static | BindingFlags.Public, null, Type.EmptyTypes, null);
        private static readonly MethodInfo _getPropertyMapMethod = typeof(Reflector).GetMethod("GetPropertyMap", BindingFlags.Static | BindingFlags.Public, null, Type.EmptyTypes, null);
        private static readonly MethodInfo _getPropertyNameMapMethod = typeof(Reflector).GetMethod("GetPropertyNameMap", BindingFlags.Static | BindingFlags.Public, null, Type.EmptyTypes, null);
        private static readonly MethodInfo _getAllPropertiesMethod = typeof(Reflector).GetMethod("GetAllProperties", Type.EmptyTypes);
        private static readonly MethodInfo _getAllPropertyPositionsMethod = typeof(Reflector).GetMethod("GetAllPropertyPositions", Type.EmptyTypes);
        private static readonly MethodInfo _getPropertyMethod = typeof(Reflector).GetMethod("GetProperty", new[] { typeof(string) });
        private static readonly MethodInfo _getInterfaceMethod = typeof(Reflector).GetMethod("GetInterface", Type.EmptyTypes);
        private static readonly MethodInfo _getInterfacesMethod = typeof(Reflector).GetMethod("GetIntefaces", Type.EmptyTypes);

        private static readonly ConcurrentDictionary<Type, RuntimeMethodHandle> _getReflectedTypeCache = new ConcurrentDictionary<Type, RuntimeMethodHandle>();
        private static readonly ConcurrentDictionary<Type, RuntimeMethodHandle> _getPropertyMapCache = new ConcurrentDictionary<Type, RuntimeMethodHandle>();
        private static readonly ConcurrentDictionary<Type, RuntimeMethodHandle> _getPropertyNameMapCache = new ConcurrentDictionary<Type, RuntimeMethodHandle>();
        private static readonly ConcurrentDictionary<Type, RuntimeMethodHandle> _getAllPropertiesCache = new ConcurrentDictionary<Type, RuntimeMethodHandle>();
        private static readonly ConcurrentDictionary<Type, RuntimeMethodHandle> _getAllPropertyPositionsCache = new ConcurrentDictionary<Type, RuntimeMethodHandle>();
        private static readonly ConcurrentDictionary<Type, RuntimeMethodHandle> _getPropertyCache = new ConcurrentDictionary<Type, RuntimeMethodHandle>();
        private static readonly ConcurrentDictionary<Type, RuntimeMethodHandle> _extractInterfaceCache = new ConcurrentDictionary<Type, RuntimeMethodHandle>();
        private static readonly ConcurrentDictionary<Type, RuntimeMethodHandle> _extractInterfacesCache = new ConcurrentDictionary<Type, RuntimeMethodHandle>();

        private static readonly ConcurrentDictionary<Type, RuntimeMethodHandle> _defaultConstructors = new ConcurrentDictionary<Type, RuntimeMethodHandle>();
        
        #endregion

        public static bool InheritsFrom(this Type thisType, Type baseType)
        {
            return baseType.IsAssignableFrom(thisType);
        }

        public static object GetDefault(this Type type)
        {
            return type.IsValueType ? System.Activator.CreateInstance(type) : null;
        }

        public static string GetFriendlyName(this Type type)
        {
            if (type.IsGenericType)
            {
                return type.Name.Split('`')[0] + "<" + string.Join(", ", type.GetGenericArguments().Select(x => GetFriendlyName(x)).ToArray()) + ">";
            }
            return type.Name;
        }

        public static object ChangeType(object value, Type conversionType)
        {
            if (conversionType == null)
            {
                throw new ArgumentNullException("conversionType");
            }

            var newConversionType = Nullable.GetUnderlyingType(conversionType);

            if (newConversionType != null)
            {
                conversionType = newConversionType;
                if (value == null)
                {
                    return null;
                }
            }

            return Convert.ChangeType(value, conversionType);
        }

        public static bool IsComparable(object objectValue)
        {
            return objectValue is IComparable;
        }

        public static bool IsDataEntity(object objectValue)
        {
            return objectValue is IDataEntity;
        }

        public static bool IsDataEntity(Type objectType)
        {
            return typeof(IDataEntity).IsAssignableFrom(objectType);
        }

        public static bool IsDataEntityList(Type objectType, out Type elementType)
        {
            var result = false;
            if (IsList(objectType))
            {
                elementType = GetElementType(objectType);
                if (elementType != null && (IsDataEntity(elementType) || !IsSimpleType(elementType)))
                {
                    result = true;
                }
            }
            else
            {
                elementType = null;
            }
            return result;
        }
        
        public static bool IsInterface(Type objectType)
        {
            return objectType != null && objectType.IsInterface;
        }

        public static bool IsValueType(Type objectType)
        {
            return objectType != null && objectType.IsValueType;
        }

        public static bool IsStringOrValueType(Type objectType)
        {
            return objectType != null && (objectType == typeof(string) || objectType.IsValueType);
        }

        public static bool IsMarkerInterface(Type objectType)
        {
            return objectType == typeof(IDataEntity) || objectType == typeof(ITrackableDataEntity);
        }

        public static bool IsMarkerInterface<T>()
        {
            return TypeCache<T>.Type.IsMarkerInterface;
        }

        public static bool IsXmlType(Type objectType)
        {
            return objectType == typeof(XmlDocument) || objectType == typeof(XDocument) || objectType == typeof(XmlReader);
        }

        public static bool IsSimpleType(Type objectType)
        {
            return IsSimpleNullableType(objectType) || IsSimpleNonNullableType(objectType);
        }

        public static bool IsSimpleNullableType(Type objectType)
        {
            if (IsNullableType(objectType))
            {
                var genericArguments = objectType.GetGenericArguments();
                if (genericArguments.Length > 0)
                {
                    return IsSimpleNonNullableType(genericArguments[0]);
                }
            }
            return false;
        }

        public static bool IsSimpleNonNullableType(Type objectType)
        {
            return IsNonTextType(objectType) || IsTextType(objectType);
        }

        public static bool IsTextType(Type objectType)
        {
            return objectType.IsEnum
                || objectType == typeof(DateTime)
                || objectType == typeof(DateTimeOffset)
                || objectType == typeof(TimeSpan)
                || objectType == typeof(string)
                || objectType == typeof(Guid);
        }

        public static bool IsNonTextType(Type objectType)
        {
            return objectType.IsPrimitive
                || objectType == typeof(decimal);
        }

        public static bool IsNullableType(Type objectType)
        {
            //return objectType.IsGenericType && objectType.GetGenericTypeDefinition().Equals(typeof(Nullable<>));
            Type dummy;
            return IsNullableType(objectType, out dummy);
        }

        public static bool IsNullableType(Type objectType, out Type underlyingType)
        {
            underlyingType = Nullable.GetUnderlyingType(objectType);
            return underlyingType != null;
        }

        public static bool IsNumeric(Type objectType)
        {
            return objectType.IsPrimitive
                    || objectType == typeof(decimal)
                    || objectType.IsEnum
                    || IsNullableNumeric(objectType);
        }

        public static bool IsNullableNumeric(Type objectType)
        {
            if (IsNullableType(objectType))
            {
                var genericArguments = objectType.GetGenericArguments();
                if (genericArguments.Length > 0)
                {
                    return IsNumeric(genericArguments[0]);
                }
            }
            return false;
        }

        public static bool IsList(Type objectType)
        {
            if (objectType.IsGenericType)
            {
                var genericTypeDefinition = objectType.GetGenericTypeDefinition();
                if (genericTypeDefinition != typeof(List<>) && genericTypeDefinition != typeof(IList<>))
                {
                    return genericTypeDefinition.Prepend(genericTypeDefinition.GetInterfaces()).Where(s => s.IsGenericType).Select(s => s.GetGenericTypeDefinition()).Contains(typeof(IList<>));
                }
                return true;
            }
            return objectType.GetInterface("System.Collections.IList") != null;
        }

        public static bool IsSimpleList(Type type)
        {
            bool result = false;
            if (IsList(type))
            {
                result = IsSimpleType(GetElementType(type));
            }
            return result;
        }

        public static bool IsDictionary(Type objectType)
        {
            if (objectType.IsGenericType)
            {
                var genericTypeDefinition = objectType.GetGenericTypeDefinition();
                if (genericTypeDefinition != typeof(Dictionary<,>) && genericTypeDefinition != typeof(IDictionary<,>))
                {
                    return genericTypeDefinition.Prepend(genericTypeDefinition.GetInterfaces()).Where(s => s.IsGenericType).Select(s => s.GetGenericTypeDefinition()).Contains(typeof(IDictionary<,>));
                }
                return true;
            }
            return objectType.GetInterface("System.Collections.IDictionary") != null;
        }

        public static bool IsArray(Type objectType)
        {
            return objectType.IsArray;
        }

        public static bool IsAnonymousType(Type objectType)
        {
            return objectType != null 
                && objectType.IsGenericType
                && (objectType.Attributes & TypeAttributes.NotPublic) == TypeAttributes.NotPublic
                && (objectType.Name.StartsWith("<>") || objectType.Name.StartsWith("VB$", StringComparison.OrdinalIgnoreCase))
                && (objectType.Name.Contains("AnonymousType") || objectType.Name.Contains("AnonType"))
                && Attribute.IsDefined(objectType, typeof(CompilerGeneratedAttribute), false);
        }

        public static bool IsEmitted(Type objectType)
        {
            return objectType != null && objectType.Assembly.IsDynamic;
        }

        public static Type GetInterface(Type objectType)
        {
            var methodHandle = _extractInterfaceCache.GetOrAdd(objectType, t => _getInterfaceMethod.MakeGenericMethod(t).MethodHandle);
            var func = Method.CreateDelegate(methodHandle);
            return (Type)func(null, new object[] { });
        }

        public static Type GetInterface<T>()
        {
            var interfaces = InterfaceCache<T>.Interfaces;
            var interfaceType = interfaces.MaxElement(k => k.Value.Count).Key;
            return interfaceType;
        }

        public static IEnumerable<Type> GetInterfaces(Type objectType)
        {
            var methodHandle = _extractInterfacesCache.GetOrAdd(objectType, t => _getInterfacesMethod.MakeGenericMethod(t).MethodHandle);
            var func = Method.CreateDelegate(methodHandle);
            return (IEnumerable<Type>)func(null, new object[] { });
        }

        public static IEnumerable<Type> GetInterfaces<T>()
        {
            var interfaces = InterfaceCache<T>.Interfaces;
            return interfaces.Keys;
        }

        private static Dictionary<Type, List<Type>> PrepareInterfaces<T>()
        {
            var interfaceTypes = GetInterfacesImplementation(typeof(T));
            var interfaceMap = new Dictionary<Type, List<Type>>();

            foreach (var interfaceType in interfaceTypes)
            {
                var interfaces = GetInterfacesImplementation(interfaceType).ToList();
                if (interfaces.Count > 0)
                {
                    interfaceMap[interfaceType] = interfaces;
                }
            }
            return interfaceMap;
        }

        private static IEnumerable<Type> GetInterfacesImplementation(Type type)
        {
            var interfaces = type.GetInterfaces();
            Array.Reverse(interfaces);
            return (type.IsInterface ? interfaces.Append(type) : interfaces).Where(t => t != typeof(IDataEntity) && typeof(IDataEntity).IsAssignableFrom(t));
        }

        public static PropertyInfo[] GetAllProperties(Type objectType)
        {
            var methodHandle = _getAllPropertiesCache.GetOrAdd(objectType, t => _getAllPropertiesMethod.MakeGenericMethod(t).MethodHandle);
            var func = Method.CreateDelegate(methodHandle);
            return (PropertyInfo[])func(null, new object[] { });
        }

        public static PropertyInfo[] GetAllProperties<T>()
        {
            var properties = PropertyCache<T>.Properties;
            return properties.Values.ToArray();
        }

        public static PropertyInfo GetProperty(Type objectType, string name)
        {
            var methodHandle = _getPropertyCache.GetOrAdd(objectType, t => _getPropertyMethod.MakeGenericMethod(t).MethodHandle);
            var func = Method.CreateDelegate(methodHandle);
            return (PropertyInfo)func(null, new object[] { name });
        }

        public static PropertyInfo GetProperty<T>(string name)
        {
           var properties = PropertyCache<T>.Properties;
            PropertyInfo property;
            properties.TryGetValue(name, out property);
            return property;
        }

        public static IDictionary<string, int> GetAllPropertyPositions(Type objectType)
        {
            var methodHandle = _getAllPropertyPositionsCache.GetOrAdd(objectType, t => _getAllPropertyPositionsMethod.MakeGenericMethod(t).MethodHandle);
            var func = Method.CreateDelegate(methodHandle);
            return (IDictionary<string, int>)func(null, new object[] { });
        }

        public static IDictionary<string, int> GetAllPropertyPositions<T>()
        {
            return PropertyCache<T>.Positions;
        }

        private static Dictionary<string, Tuple<PropertyInfo, int>> PrepareAllProperties<T>()
        {
            var typeList = new HashSet<Type>();
            foreach (var interfaceType in GetInterfaces<T>(/*objectType*/))
            {
                typeList.Add(interfaceType);
            }
            typeList.Add(typeof(T)/*objectType*/);

            var map = new Dictionary<string, Tuple<PropertyInfo, int>>();

            var index = 0;
            foreach (var type in typeList)
            {
                foreach (var property in type.GetProperties())
                {
                    map[property.Name] = Tuple.Create(property, index);
                    index++;
                }
            }

            return map;
        }

        public static IDictionary<PropertyInfo, ReflectedProperty> GetPropertyMap(Type objectType)
        {
            //var type = !objectType.IsInterface ? Reflector.GetInterface(objectType) : objectType;
            var methodHandle = _getPropertyMapCache.GetOrAdd(objectType, t => _getPropertyMapMethod.MakeGenericMethod(t).MethodHandle);
            var func = Method.CreateDelegate(methodHandle);
            return (IDictionary<PropertyInfo, ReflectedProperty>)func(null, new object[] { });
        }

        public static IDictionary<PropertyInfo, ReflectedProperty> GetPropertyMap<T>()
        {
            return PropertyCache<T>.Map;
        }

        public static IDictionary<string, ReflectedProperty> GetPropertyNameMap(Type objectType)
        {
            var methodHandle = _getPropertyNameMapCache.GetOrAdd(objectType, t => _getPropertyNameMapMethod.MakeGenericMethod(t).MethodHandle);
            var func = Method.CreateDelegate(methodHandle);
            return (IDictionary<string, ReflectedProperty>)func(null, new object[] { });
        }

        public static IDictionary<string, ReflectedProperty> GetPropertyNameMap<T>()
        {
            return PropertyCache<T>.NameMap;
        }

        public static ReflectedType GetReflectedType(Type objectType)
        {
            var methodHandle = _getReflectedTypeCache.GetOrAdd(objectType, t => _getReflectedTypeMethod.MakeGenericMethod(t).MethodHandle);
            var func = Method.CreateDelegate(methodHandle);
            return (ReflectedType)func(null, new object[] { });
        }

        public static ReflectedType GetReflectedType<T>()
        {
            return TypeCache<T>.Type;
        }
        
        public static RuntimeMethodHandle GetDefaultConstructor(Type objectType)
        {
            var ctor = _defaultConstructors.GetOrAdd(objectType, type => type.GetConstructor(Type.EmptyTypes).MethodHandle);
            return ctor;
        }

        public static IEnumerable<Type> AllTypes()
        {
            var appDomain = AppDomain.CurrentDomain;
            var assemblies = appDomain.GetAssemblies();
            foreach (var asm in assemblies)
            {
                Type[] types = null;
                try
                {
                    types = asm.GetTypes();
                }
                catch
                {
                }

                if (types != null)
                {
                    foreach (var type in types)
                    {
                        yield return type;
                    }
                }
            }
        }

        public static IEnumerable<Type> AllDataEntityTypes()
        {
            return AllTypes().Where(IsDataEntity);
        }

        public static IEnumerable<MethodInfo> GetExtensionMethods(this Type extendedType)
        {
            var methods = extendedType.Assembly.GetTypes()
                .Where(t => t.IsSealed && !t.IsGenericType && !t.IsNested)
                .SelectMany(t => t.GetMethods(BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic))
                .Where(m => m.IsDefined(typeof(ExtensionAttribute), false) && m.GetParameters()[0].ParameterType == extendedType);
            return methods;
        }

        public static IList<TAttribute> GetAttributeList<T, TAttribute>()
            where TAttribute : Attribute
        {
            return ClassAttributeListCache<T, TAttribute>.AttributeList;
        }

        public static TAttribute GetAttribute<T, TAttribute>(bool assemblyLevel = false, bool inherit = false)
            where TAttribute : Attribute
        {
            TAttribute attribute = null;
            if (!typeof(T).IsValueType)
            {
                attribute = assemblyLevel ? typeof(T).Assembly.GetCustomAttributes(typeof(T), inherit).OfType<TAttribute>().FirstOrDefault() : (inherit ? ClassHierarchyAttributeCache<T, TAttribute>.Attribute : ClassAttributeCache<T, TAttribute>.Attribute);
            }
            return attribute;
        }

        public static T GetAttribute<T>(Type objectType, bool assemblyLevel = false, bool inherit = false)
            where T : Attribute
        {
            if (objectType == null || objectType.IsValueType) return null;
            var attributes = assemblyLevel ? objectType.Assembly.GetCustomAttributes(typeof(T), inherit) : objectType.GetCustomAttributes(typeof(T), inherit);
            var attribute = attributes.Cast<T>().FirstOrDefault();
            return attribute;
        }

        public static Type GetType(string typeName)
        {
            return Type.GetType(typeName, false, true);
        }

        public static Type GetElementType(Type collectionType)
        {
            var ienum = FindEnumerable(collectionType);
            return ienum != null ? ienum.GetGenericArguments()[0] : null;
        }

        private static Type FindEnumerable(Type collectionType)
        {
            if (collectionType == null || collectionType == typeof(string))
            {
                return null;
            }

            if (collectionType.IsArray)
            {
                return typeof(IEnumerable<>).MakeGenericType(collectionType.GetElementType());
            }

            if (collectionType.IsGenericType)
            {
                foreach (var arg in collectionType.GetGenericArguments())
                {
                    var ienum = typeof(IEnumerable<>).MakeGenericType(arg);
                    if (ienum.IsAssignableFrom(collectionType))
                    {
                        return ienum;
                    }
                }
            }

            var interfaces = collectionType.GetInterfaces();
            if (interfaces.Length > 0)
            {
                foreach (var iface in interfaces)
                {
                    var ienum = FindEnumerable(iface);
                    if (ienum != null) return ienum;
                }
            }

            if (collectionType.BaseType != null && collectionType.BaseType != typeof(object))
            {
                return FindEnumerable(collectionType.BaseType);
            }

            return null;
        }

        #region CLR to DB Type

        private static readonly Dictionary<Type, DbType> _clrToDbTypeLookup = new Dictionary<Type, DbType>
        {
            {typeof(bool),DbType.Boolean},
            {typeof(bool?),DbType.Boolean},
            {typeof(byte),DbType.Byte},
            {typeof(byte?),DbType.Byte},
            {typeof(short),DbType.UInt16},
            {typeof(short?),DbType.UInt16},
            {typeof(int),DbType.Int32},
            {typeof(int?),DbType.Int32},
            {typeof(long),DbType.Int64},
            {typeof(long?),DbType.Int64},
            {typeof(sbyte),DbType.SByte},
            {typeof(sbyte?),DbType.SByte},
            {typeof(uint),DbType.UInt32},
            {typeof(uint?),DbType.UInt32},
            {typeof(ushort),DbType.UInt16},
            {typeof(ushort?),DbType.UInt16},
            {typeof(ulong),DbType.UInt64},
            {typeof(ulong?),DbType.UInt64},
            {typeof(decimal),DbType.Decimal},
            {typeof(decimal?),DbType.Decimal},
            {typeof(float),DbType.Single},
            {typeof(float?),DbType.Single},
            {typeof(double),DbType.Double},
            {typeof(double?),DbType.Double},
            {typeof(char),DbType.String},
            {typeof(char?),DbType.String},
            {typeof(string),DbType.String},
            {typeof(DateTime),DbType.DateTime},
            {typeof(DateTime?),DbType.DateTime},
            {typeof(DateTimeOffset),DbType.DateTimeOffset},
            {typeof(DateTimeOffset?),DbType.DateTimeOffset},
            {typeof(TimeSpan),DbType.Time},
            {typeof(TimeSpan?),DbType.Time},
            {typeof(byte[]),DbType.Binary},
            {typeof(Guid),DbType.Guid},           
            {typeof(Guid?),DbType.Guid},           
            {typeof(object),DbType.Object}
        };

        internal static DbType ClrToDbType(Type clrType)
        {
            DbType dbType;
            if (clrType == null)
            {
                dbType = DbType.Xml;
            }
            else if (!_clrToDbTypeLookup.TryGetValue(clrType, out dbType))
            {
                dbType = clrType.IsEnum ? DbType.Int32 : DbType.Xml; 
            }
            return dbType;
        }

        #endregion

        #region CLR to XML Schema Type

        private static readonly Dictionary<Type, string> _clrToXmlLookup = new Dictionary<Type, string>
        {
            {typeof(Uri),"xs:anyURI"},
            {typeof(byte),"xs:unsignedByte"},
            {typeof(sbyte),"xs:byte"},
            {typeof(byte[]), "xs:base64Binary"},
            {typeof(bool),"xs:boolean"},
            {typeof(DateTimeOffset),"xs:dateTime"},
            {typeof(DateTime),"xs:dateTime"},
            {typeof(TimeSpan),"xs:diration"},
            {typeof(decimal),"xs:decimal"},
            {typeof(double),"xs:double"},
            {typeof(float),"xs:float"},
            {typeof(short),"xs:short"},
            {typeof(int),"xs:int"},
            {typeof(long),"xs:long"},
            {typeof(ushort),"xs:unsignedShort"},
            {typeof(uint), "xs:unsignedInt"},
            {typeof(ulong),"xs:unsignedLong"},
            {typeof(string), "xs:string"},
            {typeof(char), "xs:string"},
            {typeof(Guid), "xs:string"}
        };

        internal static string SimpleClrToXmlType(Type clrType)
        {
            while (true)
            {
                string schemaType;
                if (IsNullableType(clrType))
                {
                    clrType = clrType.GetGenericArguments()[0];
                    continue;
                }
                if (!_clrToXmlLookup.TryGetValue(clrType, out schemaType))
                {
                    schemaType = string.Empty;
                }
                return schemaType;
            }
        }

        internal static string ClrToXmlType(Type clrType)
        {
            while (true)
            {
                var reflectedType = GetReflectedType(clrType);

                var schemaType = string.Empty;
                if (reflectedType.IsNullableType)
                {
                    clrType = clrType.GetGenericArguments()[0];
                    continue;
                }
                if (clrType == typeof(string) || clrType.IsValueType)
                {
                    if (!_clrToXmlLookup.TryGetValue(clrType, out schemaType))
                    {
                        schemaType = string.Empty;
                    }
                }
                else if (reflectedType.IsSimpleList)
                {
                    schemaType = "xs:anyType";
                }
                else if (reflectedType.IsDataEntity)
                {
                    schemaType = clrType.Name;
                    if (IsEmitted(clrType))
                    {
                        schemaType = GetInterface(clrType).Name;
                    }
                }
                else if (reflectedType.IsList)
                {
                    var elementType = reflectedType.ElementType;
                    if (IsEmitted(elementType))
                    {
                        elementType = GetInterface(elementType);
                    }
                    schemaType = "ArrayOf" + elementType.Name;
                }
                return schemaType;
            }
        }

        public static ObjectTypeCode GetObjectTypeCode(Type type)
        {
            var typeCode = Type.GetTypeCode(type);
            switch (typeCode)
            {
                case TypeCode.Boolean:
                    return ObjectTypeCode.Boolean;
                case TypeCode.Byte:
                    return ObjectTypeCode.Byte;
                case TypeCode.UInt16:
                    return ObjectTypeCode.UInt16;
                case TypeCode.UInt32:
                    return ObjectTypeCode.UInt32;
                case TypeCode.UInt64:
                    return ObjectTypeCode.UInt64;
                case TypeCode.SByte:
                    return ObjectTypeCode.SByte;
                case TypeCode.Int16:
                    return ObjectTypeCode.Int16;
                case TypeCode.Int32:
                    return ObjectTypeCode.Int32;
                case TypeCode.Int64:
                    return ObjectTypeCode.Int64;
                case TypeCode.Char:
                    return ObjectTypeCode.Char;
                case TypeCode.String:
                    return ObjectTypeCode.String;
                case TypeCode.Single:
                    return ObjectTypeCode.Single;
                case TypeCode.Double:
                    return ObjectTypeCode.Double;
                case TypeCode.Decimal:
                    return ObjectTypeCode.Decimal;
                case TypeCode.DateTime:
                    return ObjectTypeCode.DateTime;
                case TypeCode.DBNull:
                    return ObjectTypeCode.DBNull;
                default:
                    var name = type.Name;

                    if (IsDataEntity(type))
                    {
                        return ObjectTypeCode.Object;
                    }

                    if (IsList(type))
                    {
                        var elementType = GetElementType(type);
                        var isEntityList = IsDataEntity(elementType) || !IsSimpleType(elementType);
                        if (isEntityList && elementType.IsAbstract && !elementType.IsInterface)
                        {
                            return ObjectTypeCode.PolymorphicObjectList;
                        }
                        return isEntityList ? ObjectTypeCode.ObjectList : ObjectTypeCode.SimpleList;
                    }

                    if (name == "Byte[]")
                    {
                        return ObjectTypeCode.ByteArray;
                    }

                    if (name == "Char[]")
                    {
                        return ObjectTypeCode.CharArray;
                    }

                    if (name == "TimeSpan")
                    {
                        return ObjectTypeCode.TimeSpan;
                    }

                    if (name == "Guid")
                    {
                        return ObjectTypeCode.Guid;
                    }

                    if (name == "DateTimeOffset")
                    {
                        return ObjectTypeCode.DateTimeOffset;
                    }

                    if (name == "Version")
                    {
                        return ObjectTypeCode.Version;
                    }

                    if (name == "Uri")
                    {
                        return ObjectTypeCode.Uri;
                    }

                    return IsDictionary(type) ? ObjectTypeCode.ObjectMap : ObjectTypeCode.Object;
            }
        }

        #endregion
        
        #region Emit Extensions

        internal static void PushInstance(this ILGenerator il, Type type)
        {
            il.Emit(OpCodes.Ldarg_0);
            if (type.IsValueType)
            {
                il.Emit(OpCodes.Unbox, type);
            }
        }

        internal static void BoxIfNeeded(this ILGenerator il, Type type)
        {
            if (type.IsValueType)
            {
                il.Emit(OpCodes.Box, type);
            }
        }

        internal static void UnboxIfNeeded(this ILGenerator il, Type type)
        {
            if (type.IsValueType)
            {
                il.Emit(OpCodes.Unbox_Any, type);
            }
        }

        internal static void EmitCastToReference(this ILGenerator il, Type type)
        {
            il.Emit(type.IsValueType ? OpCodes.Unbox_Any : OpCodes.Castclass, type);
        }

        internal static void EmitFastInt(this ILGenerator il, int value)
        {
            switch (value)
            {
                case -1:
                    il.Emit(OpCodes.Ldc_I4_M1);
                    return;
                case 0:
                    il.Emit(OpCodes.Ldc_I4_0);
                    return;
                case 1:
                    il.Emit(OpCodes.Ldc_I4_1);
                    return;
                case 2:
                    il.Emit(OpCodes.Ldc_I4_2);
                    return;
                case 3:
                    il.Emit(OpCodes.Ldc_I4_3);
                    return;
                case 4:
                    il.Emit(OpCodes.Ldc_I4_4);
                    return;
                case 5:
                    il.Emit(OpCodes.Ldc_I4_5);
                    return;
                case 6:
                    il.Emit(OpCodes.Ldc_I4_6);
                    return;
                case 7:
                    il.Emit(OpCodes.Ldc_I4_7);
                    return;
                case 8:
                    il.Emit(OpCodes.Ldc_I4_8);
                    return;
            }

            if (value > -129 && value < 128)
            {
                il.Emit(OpCodes.Ldc_I4_S, (SByte)value);
            }
            else
            {
                il.Emit(OpCodes.Ldc_I4, value);
            }
        }

        #endregion

        internal static class InterfaceCache<T>
        {
            static InterfaceCache()
            {
                Interfaces = PrepareInterfaces<T>();
            }
            public static readonly Dictionary<Type, List<Type>> Interfaces;
        }

        internal static class PropertyCache<T>
        {
            static PropertyCache()
            {
                var cachedProperties = PrepareAllProperties<T>();
                Properties = new ReadOnlyDictionary<string, PropertyInfo>(cachedProperties.ToDictionary(p => p.Key, p => p.Value.Item1));
                Positions = new ReadOnlyDictionary<string, int>(cachedProperties.ToDictionary(p => p.Key, p => p.Value.Item2));

                var map = MappingFactory.GetEntityMap(typeof(T));
                if (map != null)
                {
                    var reflectedProperties = map.Properties.ToDictionary(p => p.Property.PropertyName, p => p.Property);
                    Map = new ReadOnlyDictionary<PropertyInfo, ReflectedProperty>(Properties.Values.ToDictionary(p => p, p =>
                    {
                        ReflectedProperty r;
                        if (!reflectedProperties.TryGetValue(p.Name, out r))
                        {
                            r = new ReflectedProperty(p, cachedProperties[p.Name].Item2);
                        }
                        return r;
                    }));
                }
                else
                {
                    Map = new ReadOnlyDictionary<PropertyInfo, ReflectedProperty>(Properties.Values.ToDictionary(p => p, p => new ReflectedProperty(p, cachedProperties[p.Name].Item2)));
                } 
                
                NameMap = new ReadOnlyDictionary<string, ReflectedProperty>(Map.ToDictionary(p => p.Key.Name, p => p.Value));
            }
            public static readonly ReadOnlyDictionary<string, PropertyInfo> Properties;
            internal static readonly ReadOnlyDictionary<PropertyInfo, ReflectedProperty> Map;
            internal static readonly ReadOnlyDictionary<string, ReflectedProperty> NameMap;
            internal static readonly ReadOnlyDictionary<string, int> Positions;
        }

        internal static class ClassAttributeCache<T, TAttribute>
            where TAttribute : Attribute
        {
            static ClassAttributeCache()
            {
                Attribute = (TAttribute)typeof(T).GetCustomAttributes(typeof(TAttribute), false).FirstOrDefault();
            }

            public static readonly TAttribute Attribute;
        }

        internal static class ClassHierarchyAttributeCache<T, TAttribute>
            where TAttribute : Attribute
        {
            static ClassHierarchyAttributeCache()
            {
                Attribute = (TAttribute)typeof(T).GetCustomAttributes(typeof(TAttribute), true).FirstOrDefault();
            }

            public static readonly TAttribute Attribute;
        }

        internal static class ClassAttributeListCache<T, TAttribute>
            where TAttribute : Attribute
        {
            static ClassAttributeListCache()
            {
                AttributeList = typeof(T).GetCustomAttributes(typeof(TAttribute), true).Cast<TAttribute>().ToList();
            }

            public static readonly IList<TAttribute> AttributeList;
        }

        internal class TypeCache<T>
        {
            static TypeCache()
            {
                Type = new ReflectedType(typeof(T));
				Type.XmlElementName = Xml.GetElementNameFromType<T>();
			}

            public readonly static ReflectedType Type;
        }
    }
}

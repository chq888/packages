﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nemo.UnitOfWork
{
    public enum ChangeTrackingMode
    {
        Default,
        Automatic,
        Manual,
        Debug
    }
}
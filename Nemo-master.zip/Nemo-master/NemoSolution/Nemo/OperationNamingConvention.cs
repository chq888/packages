﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nemo
{
    public enum OperationNamingConvention
    {
        Default,
        Operation,
        PrefixOperation,
        PrefixTypeName_Operation,
        PrefixTypeNameOperation,
        TypeName_Operation,
        TypeNameOperation,
        PrefixOperation_TypeName,
        PrefixOperationTypeName,
        Operation_TypeName,
        OperationTypeName
    }
}

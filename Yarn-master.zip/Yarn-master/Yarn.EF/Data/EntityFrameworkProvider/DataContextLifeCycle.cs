namespace Yarn.Data.EntityFrameworkProvider
{
    public enum DataContextLifeCycle
    {
        Repository, DataContextCache
    }
}
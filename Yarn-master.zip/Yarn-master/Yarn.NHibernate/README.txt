Apache Lucene.Net README file

The package named "Lucene" is DEPRECATED.
You probably received this package because you updated the references of a project that used it.
Lucene.net has been updated, but we recommend you change your reference to the package named "Lucene.Net".

Thank you for reading and sorry for the inconvenience.

The Lucene.NET Community
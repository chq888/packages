#The EasyNetQ Hall Of Fame

A list of all the people who contributed code to the project. Generated from Git logs:

    git shortlog -s -n

No particular order. Don't forget to add your name with your pull request.

* James Crowley
* Eric Rolnicki
* Fawad Halim
* Wiebe Tijsma
* Jeff Doolittle
* Stefan Sedich
* chrisedebo
* Sren Truds Mahon
* Daniel Wertheim
* Chris Edwards
* jonnii
* Daniel Bryars
* John-Mark Newton
* Yury Pliner
* Andrew Browne
* e.bartkus
* Jos van der Til
* Bressain Dinkelman
* Daniel White
* Egidijus Bartkus
* Etienne Tremblay
* Eugene Sergueev
* m.denny
* philip hoy
* tardal
* Sekhar Panja
* Svein Erik
* John Efford
* owen_thomson
* Gediminas Guoba
* Garry Shutler
* ahazelwood
* ccellar
* chedegaard
* Fydon
* Christoph Keller
* egidijus.bartkus
* Bryan Clark
* taylorwood
* mark.harrison
* mhanney
* mwissman
* Nick Van Eeckhout
* Richard Green
* Sebastien Lambla
* Karl Nilsson
* Mike Hadlow
* Andrey Katamanov
* Jeff Huntsman
* Mathieu Leenhardt
* Steven Bone
* Matt Davey
* Dan Barua
* Alex Wiese
﻿namespace EasyNetQ.Consumer
{
    public enum StartConsumingStatus
    {
        Succeed,
        Failed,
    }
}
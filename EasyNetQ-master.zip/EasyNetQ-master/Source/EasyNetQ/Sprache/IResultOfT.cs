﻿namespace Sprache
{
    public interface IResult<out T>
    {
    }
}

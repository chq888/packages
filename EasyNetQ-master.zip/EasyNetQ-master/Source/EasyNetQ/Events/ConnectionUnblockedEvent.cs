namespace EasyNetQ.Events
{
    public class ConnectionUnblockedEvent
    {
    }
}
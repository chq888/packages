﻿namespace EasyNetQ.Events
{
    public class ConnectionCreatedEvent
    {
    }
}
﻿namespace EasyNetQ.Events
{
    public class ConnectionDisconnectedEvent
    {
    }
}
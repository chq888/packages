﻿namespace EasyNetQ.Topology
{
    public interface IBindable
    {
    }
}
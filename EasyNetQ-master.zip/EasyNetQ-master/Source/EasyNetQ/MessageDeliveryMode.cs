﻿namespace EasyNetQ
{
    public static class MessageDeliveryMode
    {
        public const byte NonPersistent = 1;
        public const byte Persistent = 2;
    }
}
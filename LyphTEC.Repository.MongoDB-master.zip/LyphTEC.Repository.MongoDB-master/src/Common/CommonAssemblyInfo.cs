using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("LyphTEC")]
[assembly: AssemblyProduct("LyphTEC.Repository.MongoDB")]
[assembly: AssemblyCopyright("Copyright \x00a9 2013. Nguyen Ly (lyphtec@gmail.com)")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: AssemblyVersion("0.9.1")]    // semver.org
[assembly: AssemblyInformationalVersion("0.9.1")]   // NuGet will use this first for version info.. we want to keep the 3 digit format common to SemVer
[assembly: AssemblyFileVersion("1.0.0.0")]
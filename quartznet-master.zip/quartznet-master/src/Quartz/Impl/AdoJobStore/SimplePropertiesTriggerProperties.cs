namespace Quartz.Impl.AdoJobStore
{
    public class SimplePropertiesTriggerProperties
    {
        public string String1 { get; set; }

        public string String2 { get; set; }

        public string String3 { get; set; }

        public int Int1 { get; set; }

        public int Int2 { get; set; }

        public long Long1 { get; set; }

        public long Long2 { get; set; }

        public decimal Decimal1 { get; set; }

        public decimal Decimal2 { get; set; }

        public bool Boolean1 { get; set; }

        public bool Boolean2 { get; set; }
    }
}